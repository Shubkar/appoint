<!DOCTYPE html>
<html lang="en">
<head>
    <title>::Invoice View::</title>
    <!--[if lt IE 10]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="description"
          content=""/>
    <meta name="keywords"
          content="">
    <meta name="author" content="etech"/>

    <link rel="icon" href="/files/assets/images/favicon.ico" type="image/x-icon">


	<link rel="stylesheet" type="text/css" href="/files/bower_components/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/files/assets/css/printCss.css" />
    </head>
<body onload="window.print()">
{!! $printData !!}
</body>
</html>