<html>
    <head>
        <title>Summary Sheet Loading</title>
    </head>
    <body>
        <script>
     window.location = "/reports/SummarySheet";
    </script>
    </body>
</html>